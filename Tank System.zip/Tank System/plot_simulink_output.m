clc; close all;
sim('tank_system');
time = h1(:, 1);

%% Step input 1, 3, 5
%% h 
hh = figure;
hold all
plot(time, h1(:, 2), 'LineWidth', 2);
plot(time, h3(:, 2), 'LineWidth', 2);
plot(time, h5(:, 2), 'LineWidth', 2);
plot(time, ones(length(time)), ':','LineWidth', 2, 'color', 'black');
plot(time, 3*ones(length(time)), ':','LineWidth', 2, 'color', 'black');
plot(time, 5*ones(length(time)), ':','LineWidth', 2, 'color', 'black');
grid on
xlabel('Time (seconds) ')
ylabel('Time Response')
title('Time Response of (h_r = 1, 3, 5) of the Tank System')
legend('h_r = 1', 'h_r = 3', 'h_r = 5')
print(hh,'-depsc','h')

%% gain k
hh = figure;
hold all
plot(time, k1(:, 2), 'LineWidth', 2);
plot(time, k3(:, 2), 'LineWidth', 2);
plot(time, k5(:, 2), 'LineWidth', 2);
grid on
xlabel('Time (seconds)')
ylabel('Time Response')
title('Gain k Variation Through the Response with h_r = 1, 3, 5')
legend('h_r = 1', 'h_r = 3', 'h_r = 5')
print(hh,'-depsc','k')


%% alpha
hh = figure;
hold all
plot(time, alpha1(:, 2), 'LineWidth', 2);
plot(time, alpha3(:, 2), 'LineWidth', 2);
plot(time, alpha5(:, 2), 'LineWidth', 2);
grid on
xlabel('Time (seconds)')
ylabel('Time Response')
title('Alpha \alpha Variation Through the Response with h_r = 1, 3, 5')
legend('h_r = 1', 'h_r = 3', 'h_r = 5')
print(hh,'-depsc','alpha')


%% beta
hh = figure;
hold all
plot(time, beta1(:, 2), 'LineWidth', 2);
plot(time, beta3(:, 2), 'LineWidth', 2);
plot(time, beta5(:, 2), 'LineWidth', 2);
grid on
xlabel('Time (seconds)')
ylabel('Time Response')
title('Beta \beta Variation Through the Response with h_r = 1, 3, 5')
legend('h_r = 1', 'h_r = 3', 'h_r = 5')
print(hh,'-depsc','beta')