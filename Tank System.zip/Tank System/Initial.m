global Ti Ab a g
g = 9.81;
Ab = 0.5;
a = 0.1*Ab;
k = 10;
wn = 10;
zeta = 0.7;
Ti = 2*zeta/wn;